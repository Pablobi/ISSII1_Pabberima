from silence.decorators import endpoint
from silence.exceptions import HTTPError

@endpoint(
    route="/teachers",
    method="GET",
    sql="SELECT * FROM Teachers",
)
def get_all():
    pass

###############################################################################

@endpoint(
    route="/teachers/$teacherID",
    method="GET",
    sql="SELECT * FROM Teachers WHERE teacherId = $teacherId",
)
def get_by_id():
    pass

###############################################################################

@endpoint(
    route="/teachers",
    method="POST",
    sql="INSERT INTO teachers \
         (name, ac, c, co, t, d, dp) \
         VALUES \
         ($name, $ac, $c, $co, $t, $d, $dp)"
)
def add(email, password, departmentId, bossId, firstName, lastName, salary):
   pass
###############################################################################

@endpoint(
    route="/subjects/$subjectId",
    method="PUT",
    sql="UPDATE Subjects SET name = $name, ac = $ac, c = $c, co = $co, t = $t, d= $d, dp = $dp \
         WHERE teacherId = $teacherId"
)
def update(name, year):
    pass

###############################################################################

@endpoint(
    route="/teachers/$teacherId",
    method="DELETE",
    sql="DELETE FROM Teachers WHERE teacherId = $teacherId"
)
def delete():
    pass
