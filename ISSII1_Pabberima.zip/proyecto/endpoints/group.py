from silence.decorators import endpoint
from silence.exceptions import HTTPError

@endpoint(
    route="/groups",
    method="GET",
    sql="SELECT * FROM Groups",
)
def get_all():
    pass

###############################################################################

@endpoint(
    route="/groups/$groupId",
    method="GET",
    sql="SELECT * FROM Groups WHERE groupId = $groupId",
)
def get_by_id():
    pass

###############################################################################

@endpoint(
    route="/classrooms/$classroomId/groups",
    method="GET",
    sql="SELECT * FROM Groups WHERE clasroomID = $classroomId",
)
def get_by_id():
    pass

###############################################################################

@endpoint(
    route="/groups",
    method="POST",
    sql="INSERT INTO Groups \
         (name, activity, year, subjectID, classroomID) \
         VALUES \
         ($name, $activity, $year, $subjectId, $classroomID)"
)
def add(name, activity, year, subjectID, classroomID):
    if not name or not activity:
        raise HTTPError(400, "name and activity are required.")

###############################################################################

@endpoint(
    route="/groups/$groupId",
    method="PUT",
    sql="UPDATE Groups SET name = $name, activity = $activity, \
         year = $year, subjectID = $subjectID, classroomID = $classroomID
)
def update(name, activity, year, subjectID, classroomID):
    pass

###############################################################################

@endpoint(
    route="/groups/$groupId",
    method="DELETE",
    sql="DELETE FROM Employees WHERE groupId = $groupId"
)
def delete():
    pass
