from silence.decorators import endpoint
from silence.exceptions import HTTPError

@endpoint(
    route="/degrees",
    method="GET",
    sql="SELECT * FROM Degrees",
)
def get_all():
    pass

###############################################################################

@endpoint(
    route="/degrees/$degreeId",
    method="GET",
    sql="SELECT * FROM Degrees WHERE degreeId = $degreeId",
)
def get_by_id():
    pass

###############################################################################

@endpoint(
    route="/degrees",
    method="POST",
    sql="INSERT INTO Degrees \
         (name, years) \
         VALUES \
         ($name, $year)"
)
def add(email, password, departmentId, bossId, firstName, lastName, salary):
    if not firstName or not lastName:
        raise HTTPError(400, "The first and last name are required.")

###############################################################################

@endpoint(
    route="/degrees/$degreeId",
    method="PUT",
    sql="UPDATE Degrees SET name = $name, year = $year \
         WHERE degreeId = $degreeId"
)
def update(name, year):
    pass

###############################################################################

@endpoint(
    route="/degrees/$degreeId",
    method="DELETE",
    sql="DELETE FROM Degrees WHERE degreeId = $degreeId"
)
def delete():
    pass
