from silence.decorators import endpoint
from silence.exceptions import HTTPError

@endpoint(
    route="/students",
    method="GET",
    sql="SELECT * FROM Students",
)
def get_all():
    pass

###############################################################################

@endpoint(
    route="/students/$studentId",
    method="GET",
    sql="SELECT * FROM Students WHERE studentId = $studentId",
)
def get_by_id():
    pass

###############################################################################

@endpoint(
    route="/students",
    method="POST",
    sql="INSERT INTO Studentss \
         (a,d,fn,sn,b,e) \
         VALUES \
         ($a, $d, $fn, $sn, $b, $e)"
)
def add(a,d,fn,sn,b,e):
    pass

###############################################################################

@endpoint(
    route="/students/$studentId",
    method="PUT",
    sql="UPDATE Students SET a =$a ,d = $d, fn = $fn,sn = $sn, b = $b,e = $e \
         WHERE subjectId = $SubjectId"
)
def update(a,d,fn,sn,b,e):
    pass

###############################################################################

@endpoint(
    route="/students/$studentId",
    method="DELETE",
    sql="DELETE FROM Students WHERE studentsId = $studentId"
)
def delete():
    pass
