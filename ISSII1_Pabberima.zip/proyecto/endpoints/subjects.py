from silence.decorators import endpoint
from silence.exceptions import HTTPError

@endpoint(
    route="/subjects",
    method="GET",
    sql="SELECT * FROM Subjects",
)
def get_all():
    pass

###############################################################################

@endpoint(
    route="/subjects/$subjectId",
    method="GET",
    sql="SELECT * FROM Subjects WHERE subjectId = $subjectId",
)
def get_by_id():
    pass

###############################################################################

@endpoint(
    route="/subjects",
    method="POST",
    sql="INSERT INTO Subjects \
         (name, ac, c, co, t, d, dp) \
         VALUES \
         ($name, $ac, $c, $co, $t, $d, $dp)"
)
def add(name, ac, c, co, t, d, dp):
    if not firstName or not lastName:
        raise HTTPError(400, "The first and last name are required.")

###############################################################################

@endpoint(
    route="/subjects/$subjectId",
    method="PUT",
    sql="UPDATE Subjects SET name = $name, ac = $ac, c = $c, co = $co, t = $t, d= $d, dp = $dp \
         WHERE subjectId = $SubjectId"
)
def update(name, ac, c, co, t, d, dp):
    pass

###############################################################################

@endpoint(
    route="/subjects/$subjectId",
    method="DELETE",
    sql="DELETE FROM Subjects WHERE subjectId = $subjectId"
)
def delete():
    pass
